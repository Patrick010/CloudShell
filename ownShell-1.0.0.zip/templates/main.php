<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/xterm/5.5.0/xterm.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/xterm/5.5.0/xterm.min.js"></script>
<div id="terminal" style="width:100%; height:500px; background-color:black;"></div>
<script src="/apps/ownShell/js/terminal.js"></script>
