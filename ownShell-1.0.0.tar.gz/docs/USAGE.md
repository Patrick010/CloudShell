# ownShell User Guide

1. Log into ownCloud.
2. Open **SSH Terminal** in the sidebar.
3. Select a whitelisted host.
4. Click **Connect**.

Authentication:
- Password or key-based.
- Idle timeout disconnects sessions.
- Session logs are recorded.
